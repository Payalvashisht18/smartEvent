import React from "react";

function VenueDetails() {
  return (
    <div>
      <h2>Venue Details</h2>
      <p>Here you will show full details of a venue</p>
    </div>
  );
}

export default VenueDetails;