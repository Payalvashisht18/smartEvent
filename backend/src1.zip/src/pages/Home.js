import { useState,useEffect } from "react";
import venues from "../data/venues";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const Home = () => {
  const [location, setLocation] = useState("");
  const [budget, setBudget] = useState("");
  const [capacity, setCapacity] = useState("");
  const [type, setType] = useState("");
  const [venues, setVenues] = useState([]);

  useEffect(() => {
    axios
      .get("http://localhost:5000/api/venues")
      .then((res) => setVenues(res.data))
      .catch((err) => console.log(err));
  }, []);
const navigate = useNavigate();
  const filteredVenues = venues.filter((v) => {
    const matchLocation = location
      ? v.location.toLowerCase().includes(location.toLowerCase())
      : true;

    const matchBudget =
      budget === "low"
        ? v.price < 20000
        : budget === "mid"
        ? v.price >= 20000 && v.price <= 50000
        : budget === "high"
        ? v.price > 50000
        : true;

    const matchCapacity =
      capacity === "small"
        ? v.capacity < 200
        : capacity === "medium"
        ? v.capacity >= 200 && v.capacity <= 500
        : capacity === "large"
        ? v.capacity > 500
        : true;

    const matchType = type ? v.type === type : true;

    return matchLocation && matchBudget && matchCapacity && matchType;
  });

  return (
    <div className="p-6 bg-gray-100 min-h-screen">

      {/* 🔥 TITLE */}
      <h1 className="text-3xl font-bold text-center mb-6">
        Find Your Perfect Venue 🎉
      </h1>

      {/* 🔍 FILTER SECTION */}
      <div className="bg-white p-4 rounded shadow flex flex-wrap gap-4 justify-center">

        <input
          type="text"
          placeholder="Location"
          className="border p-2 rounded"
          onChange={(e) => setLocation(e.target.value)}
        />

        <select onChange={(e) => setBudget(e.target.value)} className="border p-2 rounded">
          <option value="">Budget</option>
          <option value="low">Below ₹20k</option>
          <option value="mid">₹20k - ₹50k</option>
          <option value="high">Above ₹50k</option>
        </select>

        <select onChange={(e) => setCapacity(e.target.value)} className="border p-2 rounded">
          <option value="">Capacity</option>
          <option value="small">Below 200</option>
          <option value="medium">200-500</option>
          <option value="large">500+</option>
        </select>

        <select onChange={(e) => setType(e.target.value)} className="border p-2 rounded">
          <option value="">Type</option>
          <option value="wedding">Wedding</option>
          <option value="birthday">Birthday</option>
          <option value="party">Party</option>
        </select>

      </div>

      {/* 🏢 VENUES */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">

        {filteredVenues.length > 0 ? (
          filteredVenues.map((v) => (
            <div
              key={v.id}
              className="bg-white rounded shadow hover:scale-105 transition"
            >
              <img
                src={v.image}
                alt="venue"
                className="w-full h-40 object-cover"
              />

              <div className="p-4">
                <h2 className="text-xl font-bold">{v.name}</h2>
                <p>📍 {v.location}</p>
                <p>💰 ₹{v.price}</p>
                <p>👥 {v.capacity} people</p>

                <button onClick={() => navigate("/booking")}
  className="bg-green-500 text-white w-full mt-3 py-2 rounded"
>
  Book Now
</button>
              </div>
            </div>
          ))
        ) : (
          <p className="text-center col-span-3">No venues found 😢</p>
        )}

      </div>

    </div>
  );
};

export default Home;