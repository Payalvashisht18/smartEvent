import { useState } from "react";
import { useNavigate } from "react-router-dom";

const Filter = () => {
  const navigate = useNavigate();

  const [location, setLocation] = useState("");
  const [budget, setBudget] = useState("");
  const [capacity, setCapacity] = useState("");
  const [type, setType] = useState("");

  const handleSearch = () => {
    navigate("/home", {
      state: { location, budget, capacity, type },
    });
  };

  return (
    <div className="flex justify-center items-center h-screen bg-gray-100">
      <div className="bg-white p-6 rounded shadow w-96">

        <h2 className="text-2xl font-bold mb-4 text-center">
          Find Your Venue 🔍
        </h2>

        {/* Location */}
        <input
          type="text"
          placeholder="Enter Location"
          className="border p-2 w-full mb-3"
          onChange={(e) => setLocation(e.target.value)}
        />

        {/* Budget */}
        <select
          className="border p-2 w-full mb-3"
          onChange={(e) => setBudget(e.target.value)}
        >
          <option value="">Select Budget</option>
          <option value="low">Below ₹20k</option>
          <option value="mid">₹20k - ₹50k</option>
          <option value="high">Above ₹50k</option>
        </select>

        {/* Capacity */}
        <select
          className="border p-2 w-full mb-3"
          onChange={(e) => setCapacity(e.target.value)}
        >
          <option value="">Capacity</option>
          <option value="small">Below 200</option>
          <option value="medium">200-500</option>
          <option value="large">500+</option>
        </select>

        {/* Type */}
        <select
          className="border p-2 w-full mb-3"
          onChange={(e) => setType(e.target.value)}
        >
          <option value="">Hall Type</option>
          <option value="wedding">Wedding</option>
          <option value="birthday">Birthday</option>
          <option value="party">Party</option>
        </select>

        <button
          onClick={handleSearch}
          className="bg-blue-500 text-white w-full py-2 rounded"
        >
          Search Venues 🔍
        </button>

      </div>
    </div>
  );
};

export default Filter;