import { useNavigate } from "react-router-dom";

const Splash = () => {
  const navigate = useNavigate();

  return (
    <div className="flex flex-col justify-center items-center h-screen bg-gradient-to-r from-blue-500 to-purple-600 text-white">
      
      <h1 className="text-5xl font-bold mb-6">SmartEvent 🎉</h1>

      <button
        onClick={() => navigate("/login")}
        className="bg-white text-black px-6 py-3 rounded-lg text-lg hover:bg-gray-200"
      >
        Get Started 🚀
      </button>

    </div>
  );
};

export default Splash;