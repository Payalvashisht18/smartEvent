import { useState } from "react";

const Booking = () => {
  const [date, setDate] = useState("");
  const [payment, setPayment] = useState("");

  const handleBooking = () => {
    if (!date || !payment) {
      alert("Fill all details ❌");
      return;
    }

    alert("Booking Confirmed 🎉");
  };

  return (
    <div className="flex justify-center items-center h-screen bg-gray-100">
      <div className="bg-white p-6 rounded shadow w-80">

        <h2 className="text-xl font-bold mb-4">Book Venue 🎉</h2>

        <input
          type="date"
          className="border p-2 w-full mb-3"
          onChange={(e) => setDate(e.target.value)}
        />

        <select
          className="border p-2 w-full mb-3"
          onChange={(e) => setPayment(e.target.value)}
        >
          <option value="">Payment Method</option>
          <option value="card">Card</option>
          <option value="upi">UPI</option>
          <option value="cash">Cash</option>
        </select>

        <button
          onClick={handleBooking}
          className="bg-green-500 text-white w-full py-2 rounded"
        >
          Confirm Booking ✅
        </button>

      </div>
    </div>
  );
};

export default Booking;