import axios from "axios";

// Base URL (backend)
const API = axios.create({
  baseURL: "http://localhost:5000/api",
});

// ================= VENUE APIs =================

// Get all venues
export const getVenues = () => API.get("/venues");

// Add venue
export const addVenue = (data) => API.post("/venues", data);

// ================= BOOKING APIs =================

// Book venue
export const bookVenue = (data) => API.post("/bookings", data);

// ================= AUTH APIs =================

// Login
export const loginUser = (data) => API.post("/auth/login", data);

// Signup
export const signupUser = (data) => API.post("/auth/signup", data);