import { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "./AuthAnimations.css";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [mounted, setMounted] = useState(false);
  const [focusedField, setFocusedField] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    setTimeout(() => setMounted(true), 50);
  }, []);

  const handleLogin = async () => {
    setLoading(true);
    try {
      const res = await axios.post("http://localhost:5000/api/auth/login", { email, password });
      alert(res.data.message);
      localStorage.setItem("token", res.data.token);
      navigate("/filter");
    } catch (err) {
      alert(err.response?.data?.message || "Login failed ❌");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="bg-blob blob-1" />
      <div className="bg-blob blob-2" />
      <div className="bg-blob blob-3" />
      <div className="bg-blob blob-4" />
      {[...Array(18)].map((_, i) => (
        <div key={i} className={`particle particle-${(i % 9) + 1}`} style={{ animationDelay: `${i * 0.4}s`, left: `${(i * 5.5 + 3) % 100}%` }} />
      ))}
      <div className="grid-overlay" />

      <div className={`auth-card ${mounted ? "card-visible" : "card-hidden"}`}>
        <div className="card-glow" />
        <div className="auth-icon-wrap">
          <div className="auth-icon">🔐</div>
        </div>
        <h2 className="auth-title">Welcome Back</h2>
        <p className="auth-subtitle">Sign in to your account</p>

        <div className={`input-group ${focusedField === "email" ? "input-focused" : ""}`}>
          <span className="input-icon">✉️</span>
          <input type="email" placeholder="Email address" className="auth-input"
            onFocus={() => setFocusedField("email")} onBlur={() => setFocusedField(null)}
            onChange={(e) => setEmail(e.target.value)} />
        </div>

        <div className={`input-group ${focusedField === "password" ? "input-focused" : ""}`}>
          <span className="input-icon">🔒</span>
          <input type="password" placeholder="Password" className="auth-input"
            onFocus={() => setFocusedField("password")} onBlur={() => setFocusedField(null)}
            onChange={(e) => setPassword(e.target.value)} />
        </div>

        <button onClick={handleLogin} className={`auth-btn ${loading ? "btn-loading" : ""}`} disabled={loading}>
          {loading ? <span className="spinner" /> : <><span>Login</span><span className="btn-arrow">→</span></>}
        </button>

        <p className="auth-switch">
          Don't have an account?{" "}
          <span className="auth-link" onClick={() => navigate("/signup")}>Create Account</span>
        </p>
      </div>
    </div>
  );
};

export default Login;
