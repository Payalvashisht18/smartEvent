import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./SplashHome.css";

const Splash = () => {
  const navigate = useNavigate();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setTimeout(() => setMounted(true), 100);
  }, []);

  return (
    <div className="splash-page">
      {/* Animated blobs */}
      <div className="splash-blob sb1" />
      <div className="splash-blob sb2" />
      <div className="splash-blob sb3" />
      <div className="splash-blob sb4" />

      {/* Stars / particles */}
      {[...Array(24)].map((_, i) => (
        <div
          key={i}
          className="star"
          style={{
            top: `${Math.random() * 100}%`,
            left: `${Math.random() * 100}%`,
            animationDelay: `${(i * 0.3) % 5}s`,
            animationDuration: `${2 + (i % 4)}s`,
            width: `${2 + (i % 3)}px`,
            height: `${2 + (i % 3)}px`,
          }}
        />
      ))}

      {/* Rings */}
      <div className="ring ring-1" />
      <div className="ring ring-2" />
      <div className="ring ring-3" />

      {/* Grid */}
      <div className="splash-grid" />

      {/* Content */}
      <div className={`splash-content ${mounted ? "splash-in" : "splash-out"}`}>
        {/* <div className="splash-emoji-wrap">
          <span className="splash-emoji">🎉</span>
        </div> */}

        <h1 className="splash-title">
          <span className="title-word title-word-1">Smart</span>
          <span className="title-word title-word-1">Event</span>
        </h1>

        <p className="splash-tagline">Find. Book. Celebrate.</p>

        <button
          className="splash-btn"
          onClick={() => navigate("/login")}
        >
          <span className="btn-text">Get Started</span>
          <span className="btn-rocket">🚀</span>
          <div className="btn-shine" />
        </button>
      </div>
    </div>
  );
};

export default Splash;
