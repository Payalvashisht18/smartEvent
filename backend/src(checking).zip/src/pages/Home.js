import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "./SplashHome.css";

const Home = () => {
  const [location, setLocation] = useState("");
  const [budget, setBudget] = useState("");
  const [capacity, setCapacity] = useState("");
  const [type, setType] = useState("");
  const [venues, setVenues] = useState([]);
  const [mounted, setMounted] = useState(false);
  const [visibleCards, setVisibleCards] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    setTimeout(() => setMounted(true), 80);
    axios
      .get("http://localhost:5000/api/venues")
      .then((res) => {
        setVenues(res.data);
        res.data.forEach((_, i) =>
          setTimeout(() => setVisibleCards((p) => [...p, i]), 100 + i * 120)
        );
      })
      .catch((err) => console.log(err));
  }, []);

  const filteredVenues = venues.filter((v) => {
    const matchLocation = location ? v.location.toLowerCase().includes(location.toLowerCase()) : true;
    const matchBudget =
      budget === "low" ? v.price < 20000
      : budget === "mid" ? v.price >= 20000 && v.price <= 50000
      : budget === "high" ? v.price > 50000
      : true;
    const matchCapacity =
      capacity === "small" ? v.capacity < 200
      : capacity === "medium" ? v.capacity >= 200 && v.capacity <= 500
      : capacity === "large" ? v.capacity > 500
      : true;
    const matchType = type ? v.type === type : true;
    return matchLocation && matchBudget && matchCapacity && matchType;
  });

  return (
    <div className="home-page">
      {/* Background */}
      <div className="home-blob hb1" />
      <div className="home-blob hb2" />
      <div className="home-blob hb3" />
      <div className="home-grid" />

      <div className={`home-content ${mounted ? "home-in" : "home-out"}`}>

        {/* Header */}
        <div className="home-header">
          <span className="home-emoji">🎉</span>
          <h1 className="home-title">Find Your Perfect Venue</h1>
          <p className="home-sub">Discover amazing spaces for every occasion</p>
        </div>

        {/* Filters */}
        <div className="filters-bar">
          <div className="filter-input-wrap">
            <span className="filter-icon">📍</span>
            <input
              type="text"
              placeholder="Search location..."
              className="filter-input"
              onChange={(e) => setLocation(e.target.value)}
            />
          </div>

          <div className="filter-select-wrap">
            <span className="filter-icon">💰</span>
            <select onChange={(e) => setBudget(e.target.value)} className="filter-select">
              <option value="">Budget</option>
              <option value="low">Below ₹20k</option>
              <option value="mid">₹20k – ₹50k</option>
              <option value="high">Above ₹50k</option>
            </select>
          </div>

          <div className="filter-select-wrap">
            <span className="filter-icon">👥</span>
            <select onChange={(e) => setCapacity(e.target.value)} className="filter-select">
              <option value="">Capacity</option>
              <option value="small">Below 200</option>
              <option value="medium">200–500</option>
              <option value="large">500+</option>
            </select>
          </div>

          <div className="filter-select-wrap">
            <span className="filter-icon">🎊</span>
            <select onChange={(e) => setType(e.target.value)} className="filter-select">
              <option value="">Type</option>
              <option value="wedding">Wedding</option>
              <option value="birthday">Birthday</option>
              <option value="party">Party</option>
            </select>
          </div>
        </div>

        {/* Results count */}
        <p className="results-count">
          {filteredVenues.length > 0
            ? `✨ Showing ${filteredVenues.length} venue${filteredVenues.length !== 1 ? "s" : ""}`
            : ""}
        </p>

        {/* Venue Cards */}
        <div className="venues-grid">
          {filteredVenues.length > 0 ? (
            filteredVenues.map((v, i) => (
              <div
                key={v.id}
                className={`venue-card ${visibleCards.includes(i) ? "card-visible" : "card-hidden"}`}
                style={{ transitionDelay: `${i * 60}ms` }}
              >
                <div className="venue-img-wrap">
                  <img src={v.image} alt="venue" className="venue-img" />
                  <div className="venue-img-overlay" />
                  <span className="venue-type-badge">{v.type}</span>
                </div>
                <div className="venue-body">
                  <h2 className="venue-name">{v.name}</h2>
                  <div className="venue-meta">
                    <span>📍 {v.location}</span>
                    <span>💰 ₹{v.price?.toLocaleString()}</span>
                    <span>👥 {v.capacity} guests</span>
                  </div>
                  <button
                    className="venue-book-btn"
                    onClick={() => navigate("/booking")}
                  >
                    <span>Book Now</span>
                    <span className="book-arrow">→</span>
                    <div className="btn-shine" />
                  </button>
                </div>
              </div>
            ))
          ) : (
            <div className="no-venues">
              <span className="no-venues-emoji">😢</span>
              <p>No venues found for your filters</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Home;
