import { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "./AuthAnimations.css";

const Signup = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [mounted, setMounted] = useState(false);
  const [focusedField, setFocusedField] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    setTimeout(() => setMounted(true), 50);
  }, []);

  const handleSignup = async () => {
    setLoading(true);
    console.log("Signup clicked");
    try {
      const res = await axios.post("http://localhost:5000/api/auth/signup", { name, email, password });
      console.log(res.data);
      alert("Signup successful ✅");
      navigate("/login");
    } catch (err) {
      console.log(err);
      alert(err.response?.data?.message || "Signup failed ❌");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page signup-page">
      <div className="bg-blob blob-1 blob-signup-1" />
      <div className="bg-blob blob-2 blob-signup-2" />
      <div className="bg-blob blob-3 blob-signup-3" />
      <div className="bg-blob blob-4" />
      {[...Array(18)].map((_, i) => (
        <div key={i} className={`particle particle-${(i % 9) + 1}`} style={{ animationDelay: `${i * 0.35}s`, left: `${(i * 5.5 + 7) % 100}%` }} />
      ))}
      <div className="grid-overlay" />

      <div className={`auth-card ${mounted ? "card-visible" : "card-hidden"}`}>
        <div className="card-glow glow-signup" />
        <div className="auth-icon-wrap">
          <div className="auth-icon">✨</div>
        </div>
        <h2 className="auth-title">Create Account</h2>
        <p className="auth-subtitle">Join us today — it's free!</p>

        <div className={`input-group ${focusedField === "name" ? "input-focused" : ""}`}>
          <span className="input-icon">👤</span>
          <input type="text" placeholder="Full name" className="auth-input"
            onFocus={() => setFocusedField("name")} onBlur={() => setFocusedField(null)}
            onChange={(e) => setName(e.target.value)} />
        </div>

        <div className={`input-group ${focusedField === "email" ? "input-focused" : ""}`}>
          <span className="input-icon">✉️</span>
          <input type="email" placeholder="Email address" className="auth-input"
            onFocus={() => setFocusedField("email")} onBlur={() => setFocusedField(null)}
            onChange={(e) => setEmail(e.target.value)} />
        </div>

        <div className={`input-group ${focusedField === "password" ? "input-focused" : ""}`}>
          <span className="input-icon">🔒</span>
          <input type="password" placeholder="Password" className="auth-input"
            onFocus={() => setFocusedField("password")} onBlur={() => setFocusedField(null)}
            onChange={(e) => setPassword(e.target.value)} />
        </div>

        <button onClick={handleSignup} className={`auth-btn signup-btn ${loading ? "btn-loading" : ""}`} disabled={loading}>
          {loading ? <span className="spinner" /> : <><span>Create Account</span><span className="btn-arrow">✓</span></>}
        </button>

        <p className="auth-switch">
          Already have an account?{" "}
          <span className="auth-link" onClick={() => navigate("/login")}>Sign In</span>
        </p>
      </div>
    </div>
  );
};

export default Signup;
