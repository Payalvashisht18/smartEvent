import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

const injectStyles = () => {
  if (document.getElementById("filter-anim")) return;
  const s = document.createElement("style");
  s.id = "filter-anim";
  s.textContent = `
    @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&display=swap');

    @keyframes fblob {
      0%,100%{ transform:translate(0,0) scale(1) rotate(0deg); }
      33%    { transform:translate(45px,-55px) scale(1.12) rotate(8deg); }
      66%    { transform:translate(-35px,35px) scale(0.9) rotate(-5deg); }
    }
    @keyframes fgrid  { 0%,100%{opacity:.3} 50%{opacity:.65} }
    @keyframes fadeUp { from{opacity:0;transform:translateY(50px) scale(0.95)} to{opacity:1;transform:translateY(0) scale(1)} }
    @keyframes float  { 0%,100%{transform:translateY(0) rotate(-4deg)} 50%{transform:translateY(-12px) rotate(4deg)} }
    @keyframes shimmer{ 0%{left:-100%} 100%{left:200%} }
    @keyframes glowPulse { 0%,100%{opacity:.5;transform:scale(1)} 50%{opacity:1;transform:scale(1.03)} }
    @keyframes spin   { to{transform:rotate(360deg)} }
    @keyframes ringOrbit { from{transform:translate(-50%,-50%) rotate(0deg) scale(1.35)} to{transform:translate(-50%,-50%) rotate(360deg) scale(1.35)} }

    .fcard {
      animation: fadeUp 0.75s cubic-bezier(0.34,1.56,0.64,1) both;
    }
    .finput, .fselect {
      width:100%; box-sizing:border-box;
      background:rgba(255,255,255,0.07) !important;
      border:1.5px solid rgba(255,255,255,0.13) !important;
      border-radius:12px !important;
      color:#fff !important;
      font-family:'Outfit',sans-serif !important;
      font-size:15px !important;
      padding:13px 16px !important;
      outline:none !important;
      transition: border-color .3s ease, background .3s ease, box-shadow .3s ease, transform .3s ease !important;
      margin-bottom:14px !important;
    }
    .finput::placeholder { color:rgba(255,255,255,0.38) !important; }
    .fselect option { background:#1a1040 !important; color:#fff !important; }
    .finput:focus, .fselect:focus {
      border-color:rgba(167,139,250,0.7) !important;
      background:rgba(124,58,237,0.13) !important;
      box-shadow:0 0 24px rgba(124,58,237,0.28) !important;
      transform:translateX(4px) !important;
    }
    .fbtn {
      transition: transform .28s cubic-bezier(0.34,1.56,0.64,1), box-shadow .28s ease !important;
    }
    .fbtn:hover {
      transform: translateY(-3px) scale(1.04) !important;
      box-shadow: 0 16px 40px rgba(124,58,237,0.6) !important;
    }
    .fbtn:active { transform: scale(0.96) !important; }
    .fbtn:hover .farr { transform: translateX(6px) scale(1.2); }
    .farr { display:inline-block; transition:transform .25s ease; }
    .ficon-wrap { animation: float 3s ease-in-out infinite; filter:drop-shadow(0 0 18px rgba(236,72,153,0.8)); }
  `;
  document.head.appendChild(s);
};

const Filter = () => {
  const navigate = useNavigate();
  const [location, setLocation] = useState("");
  const [budget,   setBudget]   = useState("");
  const [capacity, setCapacity] = useState("");
  const [type,     setType]     = useState("");
  const [ready,    setReady]    = useState(false);

  useEffect(() => {
    injectStyles();
    setTimeout(() => setReady(true), 80);
  }, []);

  const handleSearch = () => {
    navigate("/home", { state: { location, budget, capacity, type } });
  };

  return (
    <div style={{
      minHeight:"100vh", display:"flex", alignItems:"center", justifyContent:"center",
      fontFamily:"'Outfit',sans-serif", position:"relative", overflow:"hidden",
      background:"linear-gradient(135deg,#0f0c29 0%,#302b63 50%,#24243e 100%)",
    }}>

      {/* ── BLOBS ── */}
      {[
        {w:580,h:580,bg:"radial-gradient(circle,#7c3aed,#4f46e5)",top:"-180px",left:"-160px",dur:11,delay:0},
        {w:420,h:420,bg:"radial-gradient(circle,#ec4899,#9333ea)",bottom:"-120px",right:"-110px",dur:13,delay:-4},
        {w:310,h:310,bg:"radial-gradient(circle,#06b6d4,#3b82f6)",top:"38%",left:"58%",dur:9,delay:-6},
        {w:260,h:260,bg:"radial-gradient(circle,#f97316,#ec4899)",bottom:"22%",left:"3%",dur:15,delay:-2},
      ].map((b,i)=>(
        <div key={i} style={{
          position:"absolute", borderRadius:"50%", filter:"blur(90px)", opacity:.55,
          width:b.w, height:b.h, background:b.bg,
          top:b.top, left:b.left, bottom:b.bottom, right:b.right,
          animation:`fblob ${b.dur}s ease-in-out ${b.delay}s infinite`,
          pointerEvents:"none",
        }}/>
      ))}

      {/* ── GRID ── */}
      <div style={{
        position:"fixed", inset:0, pointerEvents:"none",
        backgroundImage:"linear-gradient(rgba(255,255,255,0.03) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,0.03) 1px,transparent 1px)",
        backgroundSize:"55px 55px", animation:"fgrid 5s ease-in-out infinite",
      }}/>

      {/* ── PULSING RINGS ── */}
      {[300,480,660].map((size,i)=>(
        <div key={i} style={{
          position:"absolute", borderRadius:"50%", border:"1px solid rgba(255,255,255,0.05)",
          width:size, height:size, left:"50%", top:"50%",
          transform:"translate(-50%,-50%)",
          animation:`glowPulse ${5+i}s ease-in-out ${i*1.2}s infinite`,
          pointerEvents:"none",
        }}/>
      ))}

      {/* ── ORBIT RING ── */}
      <div style={{
        position:"absolute", width:160, height:160, borderRadius:"50%",
        border:"1.5px dashed rgba(167,139,250,0.25)", left:"50%", top:"50%",
        animation:"ringOrbit 12s linear infinite", pointerEvents:"none",
      }}>
        <div style={{position:"absolute",top:-4,left:"50%",transform:"translateX(-50%)",width:8,height:8,borderRadius:"50%",background:"#a78bfa",boxShadow:"0 0 8px #a78bfa"}}/>
      </div>

      {/* ── CARD ── */}
      <div className="fcard" style={{
        position:"relative", zIndex:10, width:"100%", maxWidth:420,
        margin:"0 16px", padding:"44px 40px 40px",
        background:"rgba(255,255,255,0.07)", backdropFilter:"blur(32px)",
        border:"1px solid rgba(255,255,255,0.14)", borderRadius:28,
        boxShadow:"0 28px 70px rgba(0,0,0,0.55), 0 0 0 1px rgba(255,255,255,0.04) inset",
        opacity: ready ? 1 : 0,
        transition:"opacity .4s ease",
      }}>

        {/* Glow behind card */}
        <div style={{
          position:"absolute", inset:-2, borderRadius:30,
          background:"linear-gradient(135deg,rgba(124,58,237,0.3),rgba(236,72,153,0.3),rgba(6,182,212,0.3))",
          zIndex:-1, filter:"blur(14px)", animation:"glowPulse 4s ease-in-out infinite",
        }}/>

        {/* Icon */}
        <div style={{textAlign:"center", marginBottom:18}}>
          <span className="ficon-wrap" style={{fontSize:52, display:"inline-block"}}>🔍</span>
        </div>

        {/* Title */}
        <h2 style={{
          textAlign:"center", margin:"0 0 6px",
          fontSize:28, fontWeight:800,
          background:"linear-gradient(135deg,#fff 20%,#c4b5fd 70%,#f9a8d4 100%)",
          WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent", backgroundClip:"text",
        }}>Find Your Venue</h2>
        <p style={{textAlign:"center",color:"rgba(255,255,255,0.4)",fontSize:14,marginBottom:28,letterSpacing:"0.5px"}}>
          Filter and discover the perfect space
        </p>

        {/* Location */}
        <input
          className="finput"
          type="text"
          placeholder="📍  Enter location"
          onChange={e => setLocation(e.target.value)}
        />

        {/* Budget */}
        <select className="fselect" onChange={e => setBudget(e.target.value)}>
          <option value="">💰  Select Budget</option>
          <option value="low">Below ₹20k</option>
          <option value="mid">₹20k – ₹50k</option>
          <option value="high">Above ₹50k</option>
        </select>

        {/* HOw much person(Capacity) */}
        <select className="fselect" onChange={e => setCapacity(e.target.value)}>
          <option value="">👥  Capacity</option>
          <option value="small">Below 200</option>
          <option value="medium">200 – 500</option>
          <option value="large">500+</option>
        </select>

        {/* Type  of Hall*/}
        <select className="fselect" onChange={e => setType(e.target.value)}>
          <option value="">🎊  Hall Type</option>
          <option value="wedding">Wedding</option>
          <option value="birthday">Birthday</option>
          <option value="party">Party</option>
        </select>

        {/* Button */}
        <button className="fbtn" onClick={handleSearch} style={{
          width:"100%", padding:"15px 0", border:"none", borderRadius:14, marginTop:6,
          background:"linear-gradient(135deg,#7c3aed,#ec4899)",
          color:"#fff", fontFamily:"'Outfit',sans-serif", fontSize:17, fontWeight:700,
          cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center",
          gap:10, position:"relative", overflow:"hidden",
          boxShadow:"0 10px 30px rgba(124,58,237,0.45)",
        }}>
          <span>Search Venues</span>
          <span className="farr">🚀</span>
          <span style={{
            position:"absolute", top:0, left:"-100%", width:"100%", height:"100%",
            background:"linear-gradient(90deg,transparent,rgba(255,255,255,0.22),transparent)",
            animation:"shimmer 2.5s ease-in-out infinite",
          }}/>
        </button>

      </div>
    </div>
  );
};

export default Filter;