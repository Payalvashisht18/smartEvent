// import { Link } from "react-router-dom";

// const Navbar = () => {
//   return (
//     <div className="flex justify-between p-4 bg-black text-white">
//       <h1>EventEase</h1>

//       <div>
//         <Link to="/" className="mr-4">Home</Link>
//         <Link to="/login" className="mr-4">Login</Link>
//         <Link to="/signup">Signup</Link>
//       </div>
//     </div>
//   );
// };

// export default Navbar;