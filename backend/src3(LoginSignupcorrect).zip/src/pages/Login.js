import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleLogin = async () => {
    try {
      const res = await axios.post(
        "http://localhost:5000/api/auth/login",
        {
          email,
          password,
        }
      );

      alert(res.data.message);

      // token save (important)
      localStorage.setItem("token", res.data.token);

      // redirect
     navigate("/filter");

    } catch (err) {
      alert(err.response?.data?.message || "Login failed ❌");
    }
  };



  return (
    <div className="flex justify-center items-center h-screen">
      <div className="bg-white p-6 rounded shadow w-80">
        <h2 className="text-xl font-bold mb-4">Login</h2>

        <input
          type="email"
          placeholder="Email"
          className="border p-2 w-full mb-3"
          onChange={(e) => setEmail(e.target.value)}
        />

        <input
          type="password"
          placeholder="Password"
          className="border p-2 w-full mb-3"
          onChange={(e) => setPassword(e.target.value)}
        />

        <button
  onClick={handleLogin}
  className="bg-blue-500 text-white w-full py-2 rounded"
>
  Login
</button>
<p className="text-center mt-3">
  Don't have an account?{" "}
  <span
    onClick={() => navigate("/signup")}
    style={{ color: "blue", cursor: "pointer" }}
  >
    Create Account
  </span>
</p>
      </div>
    </div>
  );
};

export default Login;