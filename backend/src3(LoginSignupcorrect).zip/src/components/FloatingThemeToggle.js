import { useState } from "react";
import { useTheme } from "../context/ThemeContext";

const FloatingThemeToggle = () => {
  const { isDark, toggle } = useTheme();
  const [hovered, setHovered] = useState(false);

  return (
    <button
      onClick={toggle}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      title={`Switch to ${isDark ? "light" : "dark"} mode`}
      style={{
        position: "fixed", top: "20px", right: "20px", zIndex: 200,
        width: "46px", height: "46px", borderRadius: "50%",
        background: isDark ? "rgba(30,30,36,0.9)" : "rgba(255,252,245,0.92)",
        border: `1.5px solid ${isDark ? "rgba(201,168,76,0.3)" : "rgba(154,122,48,0.3)"}`,
        backdropFilter: "blur(16px)",
        cursor: "pointer",
        fontSize: "20px",
        display: "flex", alignItems: "center", justifyContent: "center",
        boxShadow: isDark
          ? "0 4px 20px rgba(0,0,0,0.4)"
          : "0 4px 20px rgba(0,0,0,0.12)",
        transform: hovered ? "scale(1.1) rotate(15deg)" : "scale(1) rotate(0deg)",
        transition: "transform 0.3s cubic-bezier(0.34,1.56,0.64,1), background 0.3s ease, box-shadow 0.3s ease",
      }}
      aria-label="Toggle theme"
    >
      <span style={{
        display: "inline-block",
        transition: "transform 0.4s ease",
        transform: isDark ? "rotate(0deg)" : "rotate(180deg)",
      }}>
        {isDark ? "🌙" : "☀️"}
      </span>
    </button>
  );
};

export default FloatingThemeToggle;
